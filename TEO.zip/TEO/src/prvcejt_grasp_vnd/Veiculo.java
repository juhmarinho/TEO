package prvcejt_grasp_vnd;

public class Veiculo {
	
	private int capacidade;

	public Veiculo() {
		
		// TODO Auto-generated constructor stub
	}

	public int getCapacidade() {
		return capacidade;
	}

	public void setCapacidade(int capacidade) {
		this.capacidade = capacidade;
	}

	

}